"""
__version__ = "$Revision: 0.1 $"
__date__ = "$Date: 2008/08/06 17:15:12 $"
"""
import libgmail
import os
import stat
import zipfile
import sys
import email
import mimetypes
import base64
from PythonCard import model, dialog
import thread, Queue, time, array

class GmailSaveGame(model.Background):

    def on_initialize(self, event):
        # if you have any initialization
        # including sizer setup, do it here

        # we are not connected to gmail
        self.connected = 0

        # initialize our game name: save game directory dict
        self.saveDir = {'default' : '/default/dir'}

        # initialize our game name: save extension dict
        defaultExt = '.save', '.sav', '.ssv'
        self.saveExt = {'default' : defaultExt}

        # initialize our game name: config file dict
        self.gameConfig = {'default':'./gsp/default.config'}

        # parse through gsp files
        self.ParseFiles()

        # create a message queue for output message thread
        self.msgQueue = Queue.Queue()

        # add a newline to our message box
        #self.println("")


        # test that our tuple dictionaries work
        #dictkey = 'quake 3'
        #print self.gameConfig[dictkey]

        pass

    # this function checks if username and password are correctly set
    def checkGmailFields(self):
        if self.components.GmailNameField.text == "":
            self.println("enter gmail username")
            return False
        if self.components.GmailPassTextField.text == "":
            self.println("enter gmail password")
            return False
        if self.components.GmailNameField.text == "Gmail Username":
            self.println("enter gmail username")
            return False
        return True
        

    # this function connects to gmail
    def connect(self,name,gmailPass):
        if not self.checkGmailFields():
            return
        if self.connected == 0:
                self.connected = 1
                self.fullAddress = name
                self.println("Connecting to Gmail..")
                # our gmail acct
                self.gmailAcct = libgmail.GmailAccount(self.fullAddress, gmailPass)
                self.println("Connected to Gmail")
                #actually connect
                self.gmailAcct.login()
        pass

    # this is our new config file wizard
    def on_newButton_mouseClick(self,event):
        # start the wizard process?
        result = dialog.alertDialog(self, 'This wizard will create a new game config, press ok to continue or x out to cancel', 'Start wizard?')
        if result.accepted == False:
            return;
        else:
            result = dialog.textEntryDialog(self,
                'What is the name of the game?',
                'Game Name',
                'MULE')
        if result.text == "":
            return;

        # at this point we have the game name (config name too)
        formatted_text = result.text.strip()
        formatted_text = formatted_text.replace(' ','_')
        configFileName = "./gsp/" + formatted_text + ".gsp"

        # the first line in the config file
        configFileOutput = "game name: " + result.text + "\n"

        # now we get the directory
        result = dialog.directoryDialog(self, 'Choose a save game directory', '')
        if result.accepted == False:
            return
        
        # the second line in the config file
        configFileOutput += "save directory: " + result.path + "\n"

        # now the save game extensions
        result = dialog.textEntryDialog(self,
            'Enter game save extensions seperated by commas, or simply * for all files',
            'Save File Extensions',
            '.ext, .ccv, .sos, .sol')      

        if result.text == '':
            return
        
        # split the save game extensions up
        splitGameExtensionsList = result.text.split(',')
        for ext in splitGameExtensionsList:
            configFileOutput += "save extension:" + ext + "\n"
            

        # write out config file
        f=open(configFileName, 'w')
        f.write(configFileOutput)
        f.close()

        # now parse the configfile
        self.ParseGSPFile(configFileName)

        #end of our def
        pass
        

    # Download Button Handler
    def on_DownloadButton_mouseClick(self, event):
        self.connect(self.components.GmailNameField.text + "@gmail.com",self.components.GmailPassTextField.text)
        if not self.connected:
            return
        # Pull message from inbox
        inboxFolder = self.gmailAcct.getMessagesByFolder('inbox')
        # Create game name hash for the selected game
        gameName = str(self.components.GameComboBox.text).replace(' ','')
        gameHash = hash(self.components.GameComboBox.text)
        self.println(self.components.GameComboBox.text)
        self.println(self.components.GameComboBox.text + ": " + str(gameHash))
        threadFound = None
        # Read through threads and pull out newest revision of the select games if it exists.  Otherwise, print message saying it doesnt
        for thread in inboxFolder:
                #print "Thread id: " + str(thread.id)
                for msg in thread:
                    #print "Message("+str(msg.number)+") id: " + str(msg.id) # + " in response to " + str(msg.rm)                    
                    #self.println(msg.subject)
                    if msg.subject.find(str(gameHash)) != -1:
                        threadFound = thread
                        break
                if threadFound:
                    break
        if threadFound > 0:
                #statusMsg = "Game thread found for " + self.components.GameComboBox.text
                #print statusMsg
                #self.println(statusMesg)
                statusMsg = "Found. "
                result = dialog.alertDialog(self, statusMsg + ' press ok to select from list, or x out to cancel', 'No Thread Found')
                if result.accepted:
                    sampleList = []
                    for msg in threadFound:
                        sampleList.append(str(msg.number))
                        #sampleList = ['quake 3', 'diablo 2', 'jazz jackrabbit']
                    result = dialog.multipleChoiceDialog(self, "Select Game(s) to Download", "AvailableGames", sampleList)
                    for selected in result.selection:
                        for msg in threadFound:
                            if str(msg.number) == selected:
                              rawmsg = email.message_from_string(msg.source)
                              counter = 1
                              #print rawmsg
                              bits = msg.source.split("------=_Part_")
                              file_bit = bits[len(bits)-2]
                              lines = file_bit.splitlines()
			      mycount = 0
                              for line in lines:
			        mycount += 1
                                if line.find('X-Attachment-Id') > -1:
					mystart = mycount + 1
					print mystart
                              f = "".join(lines[mystart:])
			      print f
                              saveName = os.path.join(os.curdir, gameName + '_v' + selected +'.zip')
                              if os.path.isfile(saveName):
                                os.remove(saveName)
                              fp = open(saveName,'wb')
                              fp.write(base64.decodestring(f))
                              fp.close()
                              #for bit in bits:
                              #  print "Another bit:"
                              #  print bit
                              for part in rawmsg.walk():
                                #print part.get_content_maintype()
                                #print part.get_content_type()
                                #print part.is_multipart()
                                if not part.get_content_type() == 'application/zip':
                                #if part.get_content_maintype() == 'multipart' or part.is_multipart():
                                  continue
                                filename = part.get_filename()
                                if not filename:
                                  ext = mimetypes.guess_extension(part.get_content_type())
                                  if not ext:
                                    ext = '.bin'
                                  filename = 'part-%03d%s' % (counter,ext)
                                counter += 1
                                #print filename
                                fp = open(os.path.join(os.curdir, filename),'wb')
                                fp.write(part.get_payload(decode=True))
                                fp.close()
                              # for attachment in msg.attachments:
                                    #self.println(attachment.filesize)
                                    #print attachment
                                    #buffer = ""
                                    #while True:
                                    #    data = self.gmailAcct.recv(1024)
                                    #    if not data:
                                    #        break
                                    #    buffer += data
                                    #print "In base 64"
                                    #print attachment.content
                                    #print "In binary"
                                    #print base64.decodestring(attachment.content)
                                    #arr = array.array('c')
                                    #arr.fromlist(attachment.content)
                                    #rets = arr.tostring()
                                    #fp = open(os.path.join(os.curdir,attachment.filename), 'wb')
                                    #fp.write(base64.decodestring(rets))
                                    #fp.close()
                                    #rawmsg = email.message_from_string(msg.source)
                                    #counter = 1
                                    #for part in rawmsg.walk():
                                    #    if part.get_content_maintype() == 'multipart':
                                    #        continue
                                    #    filename = part.get_filename()
                                    #    if not filename:
                                    #        ext = mimetypes.guess_extension(part.get_type())
                                    #        if not ext:
                                    #            ext = '.bin'
                                    #        filename = 'part-%03d%s' % (counter, ext)
                                    #    counter += 1
                                    #    print filename
                                    #    fp = open(os.path.join(os.curdir,filename), 'wb')
                                    #    fp.write(part.get_payload(decode=True))
                                    #    fp.close()
        pass


    # Upload Button Handler
    def on_UploadButton_mouseClick(self, event):
        
        # have we selected a game?
        if self.components.GameComboBox.text == 'Select Game':
            result = dialog.alertDialog(self, 'Select a Game to Upload', 'Select a Game')
            return

        # does the directory exist?
        directory = self.saveDir[self.components.GameComboBox.text]
        if not os.path.isdir(directory):
            result = dialog.alertDialog(self, 'Wrong directory, press ok to browse for it ok x out to cancel', 'Bad directory')
            if result.accepted == True:
                result = dialog.directoryDialog(self, 'Choose a save game directory', '')
                if result.accepted == True:
                    self.saveDir[self.components.GameComboBox.text] = result.path
                    outputmsg = "\nyou set the save directory for " + self.components.GameComboBox.text + " to " + result.path + "\n"
                    self.println(outputmsg);
                else:
                    return
            else:
                self.println("Did not select directory..")
                return


        # connect
        self.connect(self.components.GmailNameField.text + "@gmail.com",self.components.GmailPassTextField.text)
        if not self.connected:
            return

        self.println("Sending zip file...")
        zipFileName = str(self.components.GameComboBox.text).replace(' ','') + '.zip'
        z = zipfile.ZipFile(zipFileName, 'w')
        self.compress(self.saveDir[self.components.GameComboBox.text],z)
        zipFileName = os.path.join(os.curdir, zipFileName)
        gameHash = hash(self.components.GameComboBox.text)
        inboxFolder = self.gmailAcct.getMessagesByFolder('inbox')
        
        gameThread = ""
        for thread in inboxFolder:
            for msg in thread:
                if msg.subject.find(str(gameHash)) != -1:
                    gameThread = str(thread.id)
                    break
        msg = libgmail.GmailComposedMessage(self.fullAddress, str(gameHash), "Add some context stuff here",filenames=[zipFileName], thread = gameThread)        
        if self.gmailAcct.sendMessage(msg):
            self.println("Message sent successfully!")
        else:
            self.println("Error sending message!")
        # Remove the file we created
        os.remove(zipFileName)
        pass

    # For recursive tree walking
    def walktree (self, top = ".", extension = ""):
        names = os.listdir(top)
        for name in names:
            if not name.startswith("."):
                try:
                    st = os.lstat(os.path.join(top, name))
                except os.error:
                    print "OS Error"
                    continue
                if stat.S_ISDIR(st.st_mode):
                    #print os.path.join(top,name) + " is a directory"
                    self.walktree (os.path.join(top, name))
                else:
                    #print os.path.join(top,name) + " is not a directory"
                    for ext in self.saveExt[self.components.GameComboBox.text]:
                        if name.endswith(ext):
                            yield os.path.join(top, name)
        pass


    # this function compresses each file of type extension(s) to a zip file
    def compress(self,path,zip_file):
        print "Examining folder: " + path + "\n"
        for root, dirs, children in os.walk(path):
	    for child in children:
                print child
                #print "."+child.split(self.saveDir[self.components.GameComboBox.text])[1]
                #try: zip_file.write(("."+child.split(self.saveDir[self.components.GameComboBox.text])[1]).encode('ascii'))
		ass = path + "/" + child
	        try: zip_file.write(ass.encode('ascii'))
                except IOError: 
                    self.println("Zip write error")
                    zip_file.close()
	    pass
        zip_file.close()
        pass

    # This function prints a line of text plus a newline constant to the output text area
    def println(self,msg):
        self.components.OutputTextArea.text += str(msg) + "\n"
        pass

    # This function parses all .gsp files in the gsp directory under the current directory
    # it passes each found file to the parsegsp function
    def ParseFiles(self):
        dirName = "./gsp/"
        dir = os.listdir(dirName)
        for fileName in dir:
            if '.gsp' in fileName:
                self.ParseGSPFile((dirName + fileName))

    # This Function pulls the game name from the passed in .gsp file
    # It then places each of these game names into the dropdown combo box
    # It then pulls the save dir and saves it into the dictionary self.saveDir
    # It then combines all save extensions into a tuple, which is saved in dictionary self.saveExt
    def ParseGSPFile(self,fileName):
        fileContents = open(fileName)
        gameName = ''
        gameExtensions = ''
        for lineContents in fileContents:

            # do we have game name?
            if "game name:" in lineContents:
                lineContents = lineContents.replace('game name:','')
                gameName = lineContents.strip()
                self.components.GameComboBox.append(gameName)
                # and add game name: config file dict entry
                self.gameConfig[gameName] = fileName
            
            # do we have save dir?
            if "save directory:" in lineContents:
                lineContents = lineContents.replace('save directory:', '');
                lineContents = lineContents.strip()
                self.saveDir[gameName] = lineContents

            # do we have extension?
            if "extension:" in lineContents:
                lineContents = lineContents.replace('extension:', '');
                lineContents = lineContents.strip()
                gameExtensions = gameExtensions + lineContents + ' '

        fileContents.close()

        # create a tuple with the returned list of game extensions
        extensionsTuple = tuple(gameExtensions.split())

        # use the game extensions tuple as a dictionary value pair
        self.saveExt[gameName] = extensionsTuple

if __name__ == '__main__':
    app = model.Application(GmailSaveGame)
    app.MainLoop()
