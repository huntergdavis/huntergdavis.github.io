{'application':{'type':'Application',
          'name':'Template',
    'backgrounds': [
    {'type':'Background',
          'name':'bgTemplate',
          'title':'Gmail Save Game',
          'size':(421, 296),
          'style':['resizeable'],

        'menubar': {'type':'MenuBar',
         'menus': [
             {'type':'Menu',
             'name':'menuFile',
             'label':'&File',
             'items': [
                  {'type':'MenuItem',
                   'name':'menuFileExit',
                   'label':'E&xit',
                   'command':'exit',
                  },
              ]
             },
         ]
     },
         'components': [

{'type':'ComboBox', 
    'name':'GameComboBox', 
    'position':(5, 8), 
    'size':(385, 31), 
    'items':[], 
    'text':'Select Game', 
    'enabled':1
    },

{'type':'Button', 
    'name':'newButton', 
    'position':(394, 12), 
    'size':(20, 24), 
    'label':'*', 
    },

{'type':'Button', 
    'name':'UploadButton', 
    'position':(4, 45), 
    'size':(199, 37), 
    'label':'Upload to Gmail', 
    },

{'type':'Button', 
    'name':'DownloadButton', 
    'position':(210, 44), 
    'size':(204, 38), 
    'label':'Download from Gmail', 
    },

{'type':'TextField', 
    'name':'GmailNameField', 
    'position':(7, 90), 
    'size':(126, -1), 
    'text':'Gmail Username', 
    },

{'type':'PasswordField', 
    'name':'GmailPassTextField', 
    'position':(8, 123), 
    'size':(125, -1), 
    },

{'type':'CheckBox', 
    'name':'ClobberCheckBox', 
    'position':(214, 88), 
    'size':(190, 31), 
    'label':'Overwrite Existing Saves?', 
    },

{'type':'TextArea', 
    'name':'OutputTextArea', 
    'position':(7, 155), 
    'size':(406, 110), 
    'text':'Welcome to Gmail Save Game Manager\n', 
    },

] # end components
} # end background
] # end backgrounds
} }
