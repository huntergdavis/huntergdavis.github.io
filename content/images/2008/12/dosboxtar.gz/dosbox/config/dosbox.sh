export DISPLAY=:0.0
Xfbdev -screen 240x320@90 -hide-cursor -br & 
dosbox  -conf ./.dosboxconf
